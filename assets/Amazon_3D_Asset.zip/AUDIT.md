# Amazon 3D asset audit

35 source images → 35 individually named PNGs. No uploaded image omitted. All rendered images were inspected visually, and all final PNGs passed the dimensions and transparency checks.

## Naming and sizes

The final role_ naming convention was used for character assets. char_ aliases were not duplicated. Existing variants receive _02; additional source roles keep descriptive role_ names. Names describe existing assets, not newly invented scenes.

| Category | Size | Count |
|---|---|---|
| Roles | 400 × 300 | 15 |
| Vehicles | 600 × 300 | 5 |
| Equipment | 400 × 300 | 9 |
| Props | 300 × 300 | 3 |
| Environment assemblies | 800 × 400 | 3 |

## Audit limits and findings

Every file is RGBA with fully transparent exterior pixels and visible subject pixels. Walls, ceilings, floors and landscape backgrounds have been removed. Associated vehicles, railings, workstations, shelving and held objects remain in some cutouts. Environment files are transparent equipment/scene assemblies, following the request to remove every background. Small soft edge/shadow pixels can remain around rendered objects.

The conversion preserves recognizable people and objects, but does not recreate every action in the requested scene descriptions. Those differences are listed below. Rendering intensity varies; the learning-ambassador portrait is more subtly stylized. Generated label text and barcodes are visual props, not operational labels.

## Requested assets not created

| Filename | Reason |
|---|---|
| `role_stower.png` | No separate stower source; the source labeled Water Spider was retained under its actual supplied role. |
| `equip_pick_screen.png` | No standalone pick-screen image; screens appear only inside other assets. |
| `prop_amazon_box_open.png` | No open-box source. |
| `prop_tote.png` | No standalone tote source; totes appear within station assets. |
| `prop_pallet_wrapped.png` | No standalone wrapped-pallet source. |
| `prop_damaged_item.png` | No damaged-item source. |
| `env_inbound_dock.png` | Source labeled dock interior actually depicts conveyors; preserved as equip_dock_conveyor.png. |
| `env_pack_floor.png` | Only a packing-station source; preserved as equip_packing_station.png. |
| `env_outbound_dock.png` | No outbound-dock source. |

## Complete source-to-output mapping

| Source | Renamed output | Size | Notes |
|---|---|---|---|
| Amazon Carrier partners.jpg | `role_carrier_partner.png` | 400 × 300 | Additional existing carrier-partner portrait. |
| Amazon Shipping parteners.jpg | `role_delivery_driver.png` | 400 × 300 | Existing delivery-driver portrait beside van; not packages loaded at dock. |
| Amazon-Pick-Packer with thier boxes.jpg | `role_packer.png` | 400 × 300 | Source shows a pick/pack associate scanning an item, not sealing a box. |
| Loading dock interior —env.jpg | `equip_dock_conveyor.png` | 400 × 300 | Source filename says loading dock interior, but visible subject is conveyors and sort chutes. Named for visible content. |
| Picker.png | `role_picker.png` | 400 × 300 | Picker holding a box; not reaching into a pod. |
| amazon delivery trucks.jpg | `vehicle_outbound_truck_02.png` | 600 × 300 | Second existing delivery-van variant. |
| amazon dock managers.jpg | `role_dock_manager.png` | 400 × 300 | Additional existing dock-manager portrait. |
| amazon learning ambassador.jpg | `role_learning_ambassador.png` | 400 × 300 | Additional existing learning-ambassador portrait; stylization is more subtle than other portraits. |
| amazon outbound team.jpg | `role_outbound_team.png` | 400 × 300 | Existing group portrait; all 15 team members retained. |
| amazon pickers.jpg | `role_picker_02.png` | 400 × 300 | Second existing picker portrait with box. |
| amazon problem solvers.jpg | `role_problem_solver.png` | 400 × 300 | Problem solver operating wheeled computer cart; no damaged item. |
| amazon robotic engineers.webp | `role_robotics_engineer.png` | 400 × 300 | Additional existing robotics-engineer portrait. |
| amazon shipping team.webp | `role_shipping.png` | 400 × 300 | Shipping partners with clipboard; not loading packages. |
| amazon slam associates.jpg | `role_slam.png` | 400 × 300 | SLAM associate standing on platform; not feeding a conveyor. |
| amazon truck drivers.png | `role_truck_driver.png` | 400 × 300 | Driver standing before trucks; not climbing out of cab. Trucks retained as associated assets, surrounding setting removed. |
| amazon water spider.jpg | `role_water_spider.png` | 400 × 300 | Source labeled Water Spider; associate at a yellow tote station. |
| amzon trucks.jpg | `vehicle_inbound_truck.png` | 600 × 300 | Existing Amazon Business box truck; not a semi reversing into dock. Closest vehicle-role match. |
| conveyor_belt 2.webp | `equip_conveyor_belt_02.png` | 400 × 300 | Second existing main-conveyor variant. |
| conveyor_belt.webp | `equip_conveyor_belt.png` | 400 × 300 | Existing conveyor with boxes; not inbound totes. |
| fulfillment-inbound associates.jpg | `role_receiving.png` | 400 × 300 | Inbound associate at railing; no scanner or pallet-unloading action. Closest receiving-role match. |
| kiva_fleet.jpg | `equip_kiva_fleet.png` | 400 × 300 | Fleet miniature retains orange bases and yellow storage pods; count differs from specified 6–8. |
| kiva_pod_eq.jpg | `equip_kiva_pod.png` | 400 × 300 | Yellow shelving pod with orange robot base; not orange shelving. |
| label_printer.jpg | `equip_label_printer.png` | 400 × 300 | Printer cutout with label; prep table removed. |
| packing_station.webp | `equip_packing_station.png` | 400 × 300 | Packing-workstation assembly; original warehouse removed. No separate packing-floor file added. |
| pick_floor_env 2.jpg | `env_pick_floor.png` | 800 × 400 | Pick-station assembly with associate; does not show a full row of pick stations. |
| prop_amazon_box_sealed.jpg | `prop_amazon_box_sealed.png` | 300 × 300 | Source includes two sealed boxes; second retains original Mom N Pop lettering. |
| robotics_floor_env 2.jpg | `env_robotics_floor.png` | 800 × 400 | Robotic shelving group on blue bases; not an overhead floor/grid scene. |
| robotics_floor_env.avif | `env_robotics_floor_02.png` | 800 × 400 | Existing green mobile robot with blue/green cart; not orange Kiva pods. |
| sealed package box.jpg | `prop_amazon_box_sealed_02.png` | 300 × 300 | Second sealed-box variant; original hands/person removed. |
| shipping_label.jpg | `prop_shipping_label.png` | 300 × 300 | Shipping-label prop; original redactions retained. Generated label/barcode is decorative, not validated for scanning. |
| slam_machine amazon.jpg | `equip_slam_machine.png` | 400 × 300 | SLAM label-applicator/conveyor assembly. |
| sorter_conveyor_amazon.jpg | `equip_sorter_conveyor.png` | 400 × 300 | Sorter conveyor with boxes and side chutes. |
| vehicle_forklift.avif | `vehicle_forklift.png` | 600 × 300 | Yellow forklift with palletized boxes; not orange or shrink-wrapped. |
| vehicle_outbound_truck.webp | `vehicle_outbound_truck.png` | 600 × 300 | Amazon delivery van; not a dock-loading scene. |
| vehicle_pallet_jack amazon.jpg | `vehicle_pallet_jack.png` | 600 × 300 | Yellow manual pallet jack, not electric and not carrying totes. |
